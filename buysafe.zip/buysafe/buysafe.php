<?php

defined('_JEXEC') or die('Restricted access');

if (!class_exists('vmPSPlugin'))
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');

class plgVmPaymentBuySafe extends vmPSPlugin {

    public static $_this = false;

    function __construct(& $subject, $config) {

        parent::__construct($subject, $config);

        $this->_loggable = true;
        $this->tableFields = array_keys($this->getTableSQLFields());
        $this->_tablepkey = 'id';
        $this->_tableId = 'id';

        $varsToPush = array(
            'test_mode' => array('', 'char'),
            'storeid' => array('', 'char'),
            'storepwd' => array('', 'char')
        );

        $this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
    }

    public function getVmPluginCreateTableSQL() {

        return $this->createTableSQL('Payment 2Checkout Table');
    }

    function getTableSQLFields() {

        $SQLfields = array(
            'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',
            'virtuemart_order_id' => 'int(1) UNSIGNED',
            'order_number' => 'varchar(64)',
            'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',
            'payment_name' => 'varchar(200)',
            'payment_order_total' => 'decimal(15,5) NOT NULL DEFAULT \'0.00000\'',
            'buysafeno' => 'varchar(64)',
            'Td' => 'varchar(64)',
            'MN' => 'varchar(64)',
            'Term' => 'varchar(2)',
            'ApproveCode' => 'varchar(64)',
            'Card_NO' => 'varchar(64)',
            'errcode' => 'varchar(64)',
            'errmsg' => 'varchar(500)',
            'Card_Type' => 'int(1) UNSIGNED NULL DEFAULT NULL',
            'ChkValue' => 'varchar(64)'
        );
        return $SQLfields;
    }

    function plgVmConfirmedOrder($cart, $order) {

        if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }

        $Term = "";
        // store plugin data 
        $dbValues['virtuemart_order_id'] = $order['details']['BT']->virtuemart_order_id;
        $dbValues['order_number'] = $order['details']['BT']->order_number;
        $dbValues['virtuemart_paymentmethod_id'] = $order['details']['BT']->virtuemart_paymentmethod_id;
        $dbValues['payment_name'] = $this->renderPluginName($method);
        $dbValues['payment_order_total'] = round($order['details']['BT']->order_total);

        $dbValues['Term'] = $Term;
        $dbValues['Card_Type'] = '0';

        $dbValues['buysafeno'] = '';
        $dbValues['Td'] = '';
        $dbValues['Mn'] = '';
        $dbValues['errcode'] = '';
        $dbValues['errmsg'] = '';
        $dbValues['ChkValue'] = '';
        $dbValues['ApproveCode'] = '';
        $dbValues['Card_NO'] = '';
        $this->storePSPluginInternalData($dbValues);


        $address = $order['details']['BT'];
        $target = "_self";
        //判斷是否測試模式
        $url = ($method->test_mode == 'no' ? 'https://www.esafe.com.tw/Service/Etopm.aspx' : 'https://test.esafe.com.tw/Service/Etopm.aspx');

        //送出付款資訊
        $shtml = '<div style="text-align:center;" ><form name="myform" id="myform" method="post" target="' . $target . '" action="' . $url . '">';
        $shtml .="<input type='hidden' name='web' value='" . $method->storeid . "' />"; //商店代號
        $shtml .="<input type='hidden' name='MN' value='" . $dbValues['payment_order_total'] . "' />"; //交易金額
        $shtml .="<input type='hidden' name='Td' value='" . $order['details']['BT']->order_number . "' />"; //商家訂單編號
        $shtml .="<input type='hidden' name='sna' value='" . $address->last_name . $address->first_name . "' />"; //消費者姓名
        if (preg_match("/^[0-9]+$/", $address->phone_2) == 1) {
            $shtml .="<input type='hidden' name='sdt' value='" . $address->phone_2 . "' />"; //消費者電話
        } else if (preg_match("/^[0-9]+$/", $address->phone_1) == 1) {
            $shtml .="<input type='hidden' name='sdt' value='" . $address->phone_1 . "' />"; //消費者電話
        }
        $shtml .="<input type='hidden' name='email' value='" . $address->email . "' />"; //消費者 Email
        $shtml .="<input type='hidden' name='Card_Type' value='0' />"; //交易類別 0 信用卡交易、1 銀聯卡交易
        //$shtml .="<input type='hidden' name='Term' value='". $Term."' />"; //分期期數
        $shtml .="<input type='hidden' name='note1' value='buysafe' />";
        $shtml .="<input type='hidden' name='ChkValue' value='" . strtoupper(sha1($method->storeid . $method->storepwd . $dbValues['payment_order_total'] . $Term)) . "' />";
        $shtml .= '<script type="text/javascript">document.myform.submit();</script>';
        $shtml .= '</form></div>';
        vRequest::setVar('html', $shtml);
        vRequest::setVar('display_title', false);

        $this->setInConfirmOrder($cart);
        $cart->emptyCart();
        vmJsApi::addJScript('vm.paymentFormAutoSubmit', '
  			jQuery(document).ready(function($){
   				jQuery("body").addClass("vmLoading");
  				var msg="' . vmText::_('VMPAYMENT_ESAFE_REDIRECT_MESSAGE') . '";
                                jQuery(".vm-order-done").html("");
   				jQuery("body").append("<div class=\"vmLoadingDiv\"><div class=\"vmLoadingDivMsg\" style=\"text-align:center;\">"+msg+"</div></div>");
                            window.setTimeout("jQuery(\'.vmLoadingDiv\').hide();",5000);
			})
		');
        return true;
    }

    function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId) {

        if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return null; // Another method was selected, do nothing
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }
        $this->getPaymentCurrency($method);
        $paymentCurrencyId = $method->payment_currency;
    }

    function plgVmOnPaymentResponseReceived(&$html,&$paymentResponse) {

        if (!class_exists('VirtueMartCart'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
        if (!class_exists('shopFunctionsF'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
        if (!class_exists('VirtueMartModelOrders'))
            require( JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php' );
        if (!class_exists('EsafePay')) {
            require_once('esafepay.php');
        }

        $op_rparam = vRequest::getRequest();

        $virtuemart_order_id = 0; //取得系統單號
        if (!($virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber($op_rparam["Td"]))) {
            return NULL;
        }
        if (($order = VirtueMartModelOrders::getOrder($virtuemart_order_id))) {
            $payment = $order["details"]["BT"];
        } else {
            return NULL;
        }
        if (!($method = $this->getVmPluginMethod($payment->virtuemart_paymentmethod_id))) {
            return null;
        }
        if ($op_rparam['note1'] != 'buysafe') {
            return NULL; // Another method was selected, do nothing
        }

        $esafepay = new EsafePay();
        $esafepay->virtuemart_order_id = $virtuemart_order_id;
        $esafepay->payment = $payment;
        $esafepay->method = $method;
        $esafepay->op_rparam = $op_rparam;
        $esafepay->modelOrder = VmModel::getModel('orders');
        $esafepay->order = $this->getDataByOrderId($virtuemart_order_id);
        //判斷是否為付款後回傳
        $dbValues = array();
        if ($esafepay->process($dbValues)) {

            $this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
            if ($op_rparam['SendType'] == 1) {
                echo '0000';
                exit();
            }

            $html = '';
            if ($dbValues["errcode"]=='00') { //成功
                $html .= vmText::_('VMPAYMENT_ESAFE_PAYMENT_SUCCESS');
            }
            elseif ($dbValues["errcode"]=='') { //中斷
                $paymentResponse = vmText::_('VMPAYMENT_ESAFE_PAYMENT_PROCESS_STATUS');
                $html .= vmText::_('VMPAYMENT_ESAFE_PAYMENT_INTERRUPT');
            }
            else { //失敗
                $paymentResponse = vmText::_('VMPAYMENT_ESAFE_PAYMENT_PROCESS_STATUS');
                $html .= sprintf(vmText::_('VMPAYMENT_ESAFE_PAYMENT_FAILURE'), (($dbValues["errcode"]!='') ? '('.$dbValues["errcode"].')':'') . urldecode($dbValues["errmsg"]));
            }

        }
        return true;
    }

    protected function checkConditions($cart, $method, $cart_prices) {
        $address = (($cart->ST == 0) ? $cart->BT : $cart->ST);

        $amount = $cart_prices['salesPrice'];
        $amount_cond = ($amount >= $method->min_amount AND $amount <= $method->max_amount
                OR ( $method->min_amount <= $amount AND ( $method->max_amount == 0) ));

        $countries = array();
        if (!empty($method->countries)) {
            if (!is_array($method->countries)) {
                $countries[0] = $method->countries;
            } else {
                $countries = $method->countries;
            }
        }

        if (!is_array($address)) {
            $address = array();
            $address['virtuemart_country_id'] = 0;
        }

        if (!isset($address['virtuemart_country_id']))
            $address['virtuemart_country_id'] = 0;
        if (in_array($address['virtuemart_country_id'], $countries) || count($countries) == 0) {
            if ($amount_cond) {
                return true;
            }
        }

        return false;
    }

    /**
     * Display stored payment data for an order
     */
    function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id) {
        if (!$this->selectedThisByMethodId($virtuemart_payment_id)) {
            return null; // Another method was selected, do nothing
        }

        if (!($payment = $this->getDataByOrderId($virtuemart_order_id) )) {
            return null;
        }
        //後台訂單付款資訊
        $html = '<table class="adminlist">' . "\n";
        $html .=$this->getHtmlHeaderBE();
        $html .= $this->getHtmlRowBE('BUYSAFE_PAYMENT_NAME', $payment->payment_name);
        $html .= $this->getHtmlRowBE('BUYSAFE_ORDER_TOTAL', round($payment->payment_order_total));
        $html .= $this->getHtmlRowBE('BUYSAFE_BUYSAFENO', $payment->buysafeno);
        $html .= $this->getHtmlRowBE('BUYSAFE_TD', $payment->Td);
        $html .= $this->getHtmlRowBE('BUYSAFE_MN', $payment->MN);
        $html .= $this->getHtmlRowBE('BUYSAFE_CARDNO', $payment->Card_NO);
        $html .= $this->getHtmlRowBE('BUYSAFE_APPROVECODE', $payment->ApproveCode);
        $html .= $this->getHtmlRowBE('BUYSAFE_ERRCODE', $payment->errcode);
        $html .= $this->getHtmlRowBE('BUYSAFE_ERRMSG', $payment->errmsg);
        $html .= '</table>' . "\n";
        return $html;
    }

    function plgVmOnStoreInstallPaymentPluginTable($jplugin_id) {

        return $this->onStoreInstallPluginTable($jplugin_id);
    }

    public function plgVmOnSelectCheckPayment(VirtueMartCart $cart) {
        return $this->OnSelectCheck($cart);
    }

    public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn) {
        return $this->displayListFE($cart, $selected, $htmlIn);
    }

    public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name) {
        return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }

    function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array()) {
        return $this->onCheckAutomaticSelected($cart, $cart_prices);
    }

    public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {
        $this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }

    function plgVmonShowOrderPrintPayment($order_number, $method_id) {
        return $this->onShowOrderPrint($order_number, $method_id);
    }

    function plgVmDeclarePluginParamsPayment($name, $id, &$data) {
        return $this->declarePluginParams('payment', $name, $id, $data);
    }

    function plgVmDeclarePluginParamsPaymentVM3(&$data) {
        return $this->declarePluginParams('payment', $data);
    }

    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table) {
        return $this->setOnTablePluginParams($name, $id, $table);
    }

}

// No closing tag
