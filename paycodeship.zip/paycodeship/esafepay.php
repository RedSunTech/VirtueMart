<?php

class EsafePay {

    public $op_rparam;
    public $virtuemart_order_id = 0;
    public $payment;
    public $method;
    public $modelOrder;
    public $order;

    function process(&$dbValues) {
        $ret = FALSE;
        $paymethod = $this->op_rparam["note1"];
        switch ($paymethod) {
            case "buysafe":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafe3":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '3';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafe6":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '6';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafe12":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '12';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafe18":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '18';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafe24":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '24';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafeunion":
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam

                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);

                    $dbValues['Term'] = '';

                    $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                    $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                    $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                    //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }
                    $ret = TRUE;
                }
                break;
            case "buysafeship":
                //判斷是否為付款後回傳
                if ($this->op_rparam["SendType"] == 1) { //背景傳送
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['StoreType']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);

                        $dbValues['Term'] = '';

                        $dbValues['Card_Type'] = $this->order->Card_Type;
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['errmsg'] = $this->order->errmsg;
                        $dbValues['StoreType'] = $this->op_rparam["StoreType"];
                        $dbValues['StoreMsg'] = urldecode($this->op_rparam["StoreMsg"]);
                        $dbValues['CargoNo'] = $this->order->CargoNo;
                        $dbValues['MN'] = $this->order->MN;
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        $dbValues['ApproveCode'] = $this->order->ApproveCode;
                        $dbValues['Card_NO'] = $this->order->Card_NO;

                        if ($this->payment->comments != vmText::_('BUYSAFE_SHIPPINGMSG') . ':' . urldecode($this->op_rparam["StoreMsg"]) . (($this->op_rparam['StoreType:']!='') ? '(' . vmText::_('BUYSAFE_ERRCODE') . ':' . $this->op_rparam['StoreType:'] . ')':'')) { //已處理過就不處理
                            $order = array();
                            $order['comments'] = vmText::_('BUYSAFE_SHIPPINGMSG') . ':' . urldecode($this->op_rparam["StoreMsg"]) . (($this->op_rparam['StoreType:']!='') ? '(' . vmText::_('BUYSAFE_ERRCODE') . ':' . $this->op_rparam['StoreType:'] . ')':'');
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        return TRUE;
                    }
                } else {
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode'] . $this->op_rparam['CargoNo']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);

                        $dbValues['Term'] = '';

                        $dbValues['Card_Type'] = $this->op_rparam["Card_Type"];
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['errcode'] = $this->op_rparam["errcode"];
                        $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                        $dbValues['StoreType'] = $this->op_rparam["StoreType"];
                        $dbValues['StoreMsg'] = urldecode($this->op_rparam["StoreMsg"]);
                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        $dbValues['ApproveCode'] = $this->op_rparam["ApproveCode"];
                        $dbValues['Card_NO'] = $this->op_rparam["Card_NO"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order
                        if ($this->payment->order_status != 'C') { //已處理過就不處理
                            $order = array();
                            if ($this->op_rparam['errcode'] == "00") {
                                $order['order_status'] = 'C';
                                $this->op_rparam['errmsg']=vmText::_('BUYSAFE_PAYMENT_SUCCESS');
                                //$order['customer_notified'] = 1;
                            }
                            $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                            $order['customer_notified'] = 1;

                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);

                            if (($this->op_rparam['errcode'] == "00") && ($this->op_rparam['CargoNo']!='')) {
                                $order['comments'] = vmText::_('BUYSAFE_CARGONO') . ':' . $this->op_rparam['CargoNo'] . sprintf(vmText::_('BUYSAFE_SHIPPING_TRACKING'), $this->op_rparam['CargoNo']);
                                $order['customer_notified'] = 1;
                                $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                            }
                        }
                        $ret = TRUE;
                    }
                }
                break;
            case "webatm":
                //判斷是否為付款後回傳
                if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                    // store op_rparam
                    $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                    $dbValues['order_number'] = $this->payment->order_number;
                    $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                    $dbValues['payment_name'] = $this->method->payment_name;
                    $dbValues['payment_order_total'] = round($this->payment->order_total);
                    $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                    $dbValues['Td'] = $this->op_rparam["Td"];
                    $dbValues['errcode'] = $this->op_rparam["errcode"];
                    $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                    $dbValues['MN'] = $this->op_rparam["MN"];
                    $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];

                    // update order
                    if ($this->payment->order_status != 'C') { //已處理過就不處理
                        $order = array();
                        if ($this->op_rparam['errcode'] == "00") {
                            $order['order_status'] = 'C';
                            $this->op_rparam['errmsg']=vmText::_('WEBATM_PAYMENT_SUCCESS');
                            //$order['customer_notified'] = 1;
                        }
                        $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                        $order['customer_notified'] = 1;

                        $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                    }

                    return TRUE;
                }
                break;
            case "webatmship":
                //判斷是否為付款後回傳
                if ($this->op_rparam["SendType"] == 1) { //背景傳送
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['StoreType']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['errmsg'] = $this->order->errmsg;
                        $dbValues['StoreType'] = $this->op_rparam["StoreType"];
                        $dbValues['StoreMsg'] = urldecode($this->op_rparam["StoreMsg"]);
                        $dbValues['MN'] = $this->order->MN;
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        if ($this->payment->comments != vmText::_('WEBATMSHIP_SHIPPINGMSG') . ':' . urldecode($this->op_rparam["StoreMsg"]) . (($this->op_rparam['StoreType:']!='') ? '(' . vmText::_('WEBATMSHIP_ERRCODE') . ':' . $this->op_rparam['StoreType:'] . ')':'')) { //已處理過就不處理
                            $order = array();
                            $order['comments'] = vmText::_('WEBATMSHIP_SHIPPINGMSG') . ':' . urldecode($this->op_rparam["StoreMsg"]) . (($this->op_rparam['StoreType:']!='') ? '(' . vmText::_('WEBATMSHIP_ERRCODE') . ':' . $this->op_rparam['StoreType:'] . ')':'');
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                } else {
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode'] . $this->op_rparam["CargoNo"]))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['errcode'] = $this->op_rparam["errcode"];
                        $dbValues['errmsg'] = urldecode($this->op_rparam["errmsg"]);
                        $dbValues['StoreType'] = $this->payment->StoreType;
                        $dbValues['StoreMsg'] = $this->payment->StoreMsg;
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order
                        if ($this->payment->order_status != 'C') { //已處理過就不處理
                            $order = array();
                            if ($this->op_rparam['errcode'] == "00") {
                                $order['order_status'] = 'C';
                                $this->op_rparam['errmsg']=vmText::_('WEBATMSHIP_PAYMENT_SUCCESS');
                                //$order['customer_notified'] = 1;
                            }
                            $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);

                            if (($this->op_rparam['errcode'] == "00") && ($this->op_rparam['CargoNo']!='')) {
                                $order['comments'] = vmText::_('WEBATMSHIP_CARGONO') . ':' . $this->op_rparam['CargoNo'] . sprintf(vmText::_('WEBATMSHIP_SHIPPING_TRACKING'), $this->op_rparam['CargoNo']);
                                $order['customer_notified'] = 1;
                                $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                            }
                        }
                        $ret = TRUE;
                    }
                }
                break;
            case "paycode":
                //判斷是否為付款後回傳
                if (!isset($this->op_rparam["SendType"]) || $this->op_rparam["SendType"] == 1) { //背景傳送
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['paycode'] = $this->order->paycode;
                        $dbValues['PayType'] = $this->op_rparam["PayType"];
                        $dbValues['errcode'] = $this->op_rparam["errcode"];
                        $dbValues['PayDate'] = $this->op_rparam["PayDate"];
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order

                        if ($this->payment->order_status != 'C') { //已處理過就不處理
                            $order = array();
                            $order['comments'] = '';
                            if ($this->op_rparam['errcode'] == "00") {
                                $order['comments'] .= vmText::_('PAYCODE_PAYMENT_SUCCESS') . (($this->op_rparam['PayDate']!='') ? (', ' . vmText::_('PAYCODE_PAYDATE') . ':' . substr($this->op_rparam['PayDate'],0,4) . '/' . substr($this->op_rparam['PayDate'],4,2) . '/' . substr($this->op_rparam['PayDate'],6,2)) : '');
                                if ($dbValues['PayType'] == 4) {
                                    $order['comments'] .= ",全家超商繳款";
                                } else if ($dbValues['PayType'] == 5) {
                                    $order['comments'] .= ",統一超商繳款";
                                } else if ($dbValues['PayType'] == 6) {
                                    $order['comments'] .= ",OK 超商繳款";
                                } else if ($dbValues['PayType'] == 7) {
                                    $order['comments'] .= ",萊爾富超商繳款";
                                }
                                $order['order_status'] = 'C';
                                $order['customer_notified'] = 1;
                            }
                            if ($this->op_rparam['errcode']!='') {$order['comments'] .= '(' . vmText::_('PAYCODE_ERRCODE') . ':' . $this->op_rparam['errcode'] . ')';}

                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                } else {
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['paycode']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['paycode'] = $this->op_rparam["paycode"];
                        $dbValues['PayType'] = $this->op_rparam["PayType"];
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['PayDate'] = $this->order->PayDate;
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order
                        if ($this->payment->order_status != 'U') { //已處理過就不處理
                            $order = array();
                            $order['comments'] = sprintf(vmText::_('PAYCODE_NOTE'), $this->op_rparam['paycode']);
                            $order['order_status'] = 'U';
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                }
                break;
            case "paycodeship":
                if (!isset($this->op_rparam["SendType"]) || $this->op_rparam["SendType"] == 1) { //背景傳送
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode'] . $this->op_rparam['CargoNo']))) {
                         // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['paycode'] = $this->order->paycode;
                        $dbValues['PayType'] = $this->op_rparam["PayType"];
                        $dbValues['errcode'] = $this->op_rparam["errcode"];
                        $dbValues['PayDate'] = $this->op_rparam["PayDate"];
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];

                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['StoreName'] = $this->op_rparam["StoreName"];
                        $dbValues['StoreID'] = $this->op_rparam["StoreID"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order

                        if ($this->payment->order_status != 'C') { //已處理過就不處理
                            $order = array();
                            $order['comments'] = '';
                            if ($this->op_rparam['errcode'] == "00") {
                                $order['comments'] .= vmText::_('PAYCODE_PAYMENT_SUCCESS') . (($this->op_rparam['PayDate']!='') ? (', ' . vmText::_('PAYCODE_PAYDATE') . ':' . substr($this->op_rparam['PayDate'],0,4) . '/' . substr($this->op_rparam['PayDate'],4,2) . '/' . substr($this->op_rparam['PayDate'],6,2)) : '');
                                if ($dbValues['PayType'] == 4) {
                                    $order['comments'] .= ",全家超商繳款";
                                } else if ($dbValues['PayType'] == 5) {
                                    $order['comments'] .= ",統一超商繳款";
                                } else if ($dbValues['PayType'] == 6) {
                                    $order['comments'] .= ",OK 超商繳款";
                                } else if ($dbValues['PayType'] == 7) {
                                    $order['comments'] .= ",萊爾富超商繳款";
                                }
                                $order['order_status'] = 'C';
                                $order['customer_notified'] = 1;
                            }
                            if ($this->op_rparam['errcode']!='') {$order['comments'] .= '(' . vmText::_('PAYCODE_ERRCODE') . ':' . $this->op_rparam['errcode'] . ')';}

                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                    elseif ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['StoreType']))) { //物流狀態回傳，更新 StoreType & StoreMsg
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['paycode'] = $this->order->paycode;
                        $dbValues['PayType'] = $this->order->PayType;
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['PayDate'] = $this->order->PayDate;
                        $dbValues['MN'] = $this->order->MN;
  
                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['StoreName'] = $this->order->StoreName;
                        $dbValues['StoreID'] = $this->order->StoreID;
                        $dbValues['StoreType'] = $this->op_rparam["StoreType"];
                        $dbValues['StoreMsg'] = $this->op_rparam["StoreMsg"];

                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];

                        if ($this->payment->order_status == 'C') { //確認付款成功後才出貨
                            if ($this->op_rparam['CargoNo'] == '' ) {
                                break;
                            }

                            $order['order_status'] = 'S';

                            if($this->op_rparam["StoreType"] == "101") { // 送達門市
                                $order['comments'] = vmText::_('24PAYSHIP_CARGONO') . ':' . $this->op_rparam['CargoNo'] . '，' .
                                $this->op_rparam["StoreMsg"];                           
                            }
                            else { // 運送中
                                $order['comments'] = vmText::_('24PAYSHIP_CARGONO') . ':' . $this->op_rparam['CargoNo'] . sprintf(vmText::_('24PAYSHIP_SHIPPING_TRACKING'), $this->op_rparam['CargoNo']);
                            }
                            
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                } else {
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['paycode']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;
                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['paycode'] = $this->op_rparam["paycode"];
                        $dbValues['PayType'] = $this->op_rparam["PayType"];
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['PayDate'] = $this->order->PayDate;
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order
                        if ($this->payment->order_status != 'U') { //已處理過就不處理
                            $order = array();
                            $order['comments'] = sprintf(vmText::_('PAYCODE_NOTE'), $this->op_rparam['paycode']);
                            $order['order_status'] = 'U';
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                }
                break;                    
            case "24pay":
                if (!isset($this->op_rparam["SendType"]) || $this->op_rparam["SendType"] == 1) { //背景傳送
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                        // store op_rparam

                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;

                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['MN'] = $this->op_rparam["MN"];

                        $dbValues['BarcodeA'] = $this->order->BarcodeA;
                        $dbValues['BarcodeB'] = $this->order->BarcodeB;
                        $dbValues['BarcodeC'] = $this->order->BarcodeC;
                        $dbValues['PostBarcodeA'] = $this->order->PostBarcodeA;
                        $dbValues['PostBarcodeB'] = $this->order->PostBarcodeB;
                        $dbValues['PostBarcodeC'] = $this->order->PostBarcodeC;
                        $dbValues['EntityATM'] = $this->order->EntityATM;

                        $dbValues['errcode'] = $this->op_rparam["errcode"];
                        $dbValues['PayDate'] = $this->op_rparam["PayDate"];
                        $dbValues['PayType'] = $this->op_rparam["PayType"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        //update order
                        if ($this->payment->order_status != 'C') { //已處理過就不處理
                            $order = array();
                            if ($this->op_rparam['errcode'] == "00") {
                                $order['order_status'] = 'C';
                                $this->op_rparam['errmsg']=vmText::_('24PAY_PAYMENT_SUCCESS');
                                //$order['customer_notified'] = 1;
                            }
                            $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                            if ($this->op_rparam['PayDate']!='') {
                                $order['comments'] .= ', ' . vmText::_('24PAY_PAYDATE') . ':' . substr($this->op_rparam['PayDate'],0,4) . '/' . substr($this->op_rparam['PayDate'],4,2) . '/' . substr($this->op_rparam['PayDate'],6,2);
                            }
                            if ($this->op_rparam["PayType"]!='') {
                                $msgTag = '24PAY_PAYTYPE' . $this->op_rparam["PayType"];
                                $order['comments'] .= ', ' . vmText::_('24PAY_PAYMENT_NAME') . ':' . vmText::_($msgTag);
                            }
                            $order['customer_notified'] = 1;

                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                } else {
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['EntityATM']))) {
                        // store op_rparam

                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;

                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['MN'] = $this->op_rparam["MN"];

                        $dbValues['BarcodeA'] = $this->op_rparam["BarcodeA"];
                        $dbValues['BarcodeB'] = $this->op_rparam["BarcodeB"];
                        $dbValues['BarcodeC'] = $this->op_rparam["BarcodeC"];
                        $dbValues['PostBarcodeA'] = $this->op_rparam["PostBarcodeA"];
                        $dbValues['PostBarcodeB'] = $this->op_rparam["PostBarcodeB"];
                        $dbValues['PostBarcodeC'] = $this->op_rparam["PostBarcodeC"];
                        $dbValues['EntityATM'] = $this->op_rparam["EntityATM"];
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['PayDate'] = $this->order->PayDate;
                        $dbValues['PayType'] = $this->order->PayType;
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order 修改為由顧客確認

                        if ($this->payment->order_status != 'U') { //已處理過就不處理
                            $order = array();
                            $order['comments'] = sprintf(vmText::_('24PAY_NOTE'), substr($this->order->DueDate,0,4) . '/' . substr($this->order->DueDate,4,2) . '/' . substr($this->order->DueDate,6,2));
                            $order['order_status'] = 'U';
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                }
                break;
            case "24payship":
                if (!isset($this->op_rparam["SendType"]) || $this->op_rparam["SendType"] == 1) { //背景傳送
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode'] . $this->op_rparam['CargoNo']))) {
                        // store op_rparam

                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;

                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['MN'] = $this->op_rparam["MN"];

                        $dbValues['BarcodeA'] = $this->order->BarcodeA;
                        $dbValues['BarcodeB'] = $this->order->BarcodeB;
                        $dbValues['BarcodeC'] = $this->order->BarcodeC;
                        $dbValues['PostBarcodeA'] = $this->order->PostBarcodeA;
                        $dbValues['PostBarcodeB'] = $this->order->PostBarcodeB;
                        $dbValues['PostBarcodeC'] = $this->order->PostBarcodeC;
                        $dbValues['EntityATM'] = $this->order->EntityATM;

                        $dbValues['errcode'] = $this->op_rparam["errcode"];
                        $dbValues['PayDate'] = $this->op_rparam["PayDate"];
                        $dbValues['PayType'] = $this->op_rparam["PayType"];

                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['StoreName'] = $this->op_rparam["StoreName"];
                        $dbValues['StoreID'] = $this->op_rparam["StoreID"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        //update order
                        if ($this->payment->order_status != 'C') { //已處理過就不處理
                            $order = array();
                            if ($this->op_rparam['errcode'] == "00") {
                                $order['order_status'] = 'C';
                                $this->op_rparam['errmsg']=vmText::_('24PAYSHIP_PAYMENT_SUCCESS');
                                //$order['customer_notified'] = 1;
                            }
                            $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                            if ($this->op_rparam['PayDate']!='') {
                                $order['comments'] .= ', ' . vmText::_('24PAYSHIP_PAYDATE') . ':' . substr($this->op_rparam['PayDate'],0,4) . '/' . substr($this->op_rparam['PayDate'],4,2) . '/' . substr($this->op_rparam['PayDate'],6,2);
                            }
                            if ($this->op_rparam["PayType"]!='') {
                                $msgTag = '24PAYSHIP_PAYTYPE' . $this->op_rparam["PayType"];
                                $order['comments'] .= ', ' . vmText::_('24PAYSHIP_PAYMENT_NAME') . ':' . vmText::_($msgTag);
                            }
                            $order['customer_notified'] = 1;

                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                    elseif ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['StoreType']))) { //物流狀態回傳，更新 StoreType & StoreMsg

                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;

                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['MN'] = $this->order->MN;

                        $dbValues['BarcodeA'] = $this->order->BarcodeA;
                        $dbValues['BarcodeB'] = $this->order->BarcodeB;
                        $dbValues['BarcodeC'] = $this->order->BarcodeC;
                        $dbValues['PostBarcodeA'] = $this->order->PostBarcodeA;
                        $dbValues['PostBarcodeB'] = $this->order->PostBarcodeB;
                        $dbValues['PostBarcodeC'] = $this->order->PostBarcodeC;
                        $dbValues['EntityATM'] = $this->order->EntityATM;

                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['PayDate'] = $this->order->PayDate;
                        $dbValues['PayType'] = $this->order->PayType;

                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['StoreName'] = $this->order->StoreName;
                        $dbValues['StoreID'] = $this->order->StoreID;
                        $dbValues['StoreType'] = $this->op_rparam["StoreType"];
                        $dbValues['StoreMsg'] = $this->op_rparam["StoreMsg"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        if ($this->payment->order_status == 'C') { //確認付款成功後才出貨
                            if ($this->op_rparam['CargoNo'] == '' ) {
                                break;
                            }

                            $order['order_status'] = 'S';

                            if($this->op_rparam["StoreType"] == "101") { // 送達門市
                                $order['comments'] = vmText::_('24PAYSHIP_CARGONO') . ':' . $this->op_rparam['CargoNo'] . '，' .
                                $this->op_rparam["StoreMsg"];                           
                            }
                            else { // 運送中
                                $order['comments'] = vmText::_('24PAYSHIP_CARGONO') . ':' . $this->op_rparam['CargoNo'] . sprintf(vmText::_('24PAYSHIP_SHIPPING_TRACKING'), $this->op_rparam['CargoNo']);
                            }

                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                } else {
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['EntityATM']))) {
                        // store op_rparam

                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);
                        $dbValues['DueDate'] = $this->order->DueDate;

                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['MN'] = $this->op_rparam["MN"];

                        $dbValues['BarcodeA'] = $this->op_rparam["BarcodeA"];
                        $dbValues['BarcodeB'] = $this->op_rparam["BarcodeB"];
                        $dbValues['BarcodeC'] = $this->op_rparam["BarcodeC"];
                        $dbValues['PostBarcodeA'] = $this->op_rparam["PostBarcodeA"];
                        $dbValues['PostBarcodeB'] = $this->op_rparam["PostBarcodeB"];
                        $dbValues['PostBarcodeC'] = $this->op_rparam["PostBarcodeC"];
                        $dbValues['EntityATM'] = $this->op_rparam["EntityATM"];
                        $dbValues['errcode'] = $this->order->errcode;
                        $dbValues['PayDate'] = $this->order->PayDate;
                        $dbValues['PayType'] = $this->order->PayType;
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order 修改為由顧客確認

                        if ($this->payment->order_status != 'U') { //已處理過就不處理
                            $order = array();
                            $order['comments'] = sprintf(vmText::_('24PAYSHIP_NOTE'), substr($this->order->DueDate,0,4) . '/' . substr($this->order->DueDate,4,2) . '/' . substr($this->order->DueDate,6,2));
                            $order['order_status'] = 'U';
                            $order['customer_notified'] = 1;
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                        }
                        $ret = TRUE;
                    }
                }
                break;    
            case "sunship":
                //判斷是否為付款後回傳
                if ($this->op_rparam["SendType"] == 1) { //背景傳送
                    if (isset($this->op_rparam["errcode"])) { //收款成功
                        if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['errcode']))) {
                            $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                            $dbValues['order_number'] = $this->payment->order_number;
                            $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                            $dbValues['payment_name'] = $this->method->payment_name;
                            $dbValues['payment_order_total'] = round($this->payment->order_total);

                            $dbValues['Td'] = $this->op_rparam["Td"];
                            $dbValues['MN'] = $this->op_rparam["MN"];
                            $dbValues['errcode'] = $this->op_rparam["errcode"];
                            //$dbValues['StoreType'] = $this->order->StoreType;
                            //$dbValues['StoreMsg'] = $this->order->StoreMsg;
                            $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];


                            if ($this->payment->order_status != 'C') { //已處理過就不處理
                                $order = array();
                                if ($this->op_rparam['errcode'] == "00") { //付款完成
                                    $order['order_status'] = 'C';
                                    $dbValues['errmsg'] = vmText::_('SUNSHIP_PAYMENT_SUCCESS');
                                }
                                $order['comments'] = vmText::_('BUYSAFE_ERRMSG') . ':' . urldecode($this->op_rparam['errmsg']) . '（' . vmText::_('BUYSAFE_ERRCODE') . ':'  . $this->op_rparam['errcode'] . '）';
                                $order['customer_notified'] = 1;
                                $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                            }
                            $ret = TRUE;
                        }
                    } else { //物流
                        if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['StoreType']))) {
                            $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                            $dbValues['order_number'] = $this->payment->order_number;
                            $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                            $dbValues['payment_name'] = $this->method->payment_name;
                            $dbValues['payment_order_total'] = round($this->payment->order_total);

                            $dbValues['Td'] = $this->op_rparam["Td"];
                            $dbValues['MN'] = $this->order->MN;
                            $dbValues['errcode'] = $this->order->errcode;
                            $dbValues['StoreType'] = $this->op_rparam["StoreType"];
                            $dbValues['StoreMsg'] = urldecode($this->op_rparam["StoreMsg"]);
                            $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];

                            if ($this->payment->comments != vmText::_('SUNSHIP_SHIPPINGMSG') . ':' . urldecode($this->op_rparam["StoreMsg"]) . (($this->op_rparam['StoreType:']!='') ? '(' . vmText::_('SUNSHIP_ERRCODE') . ':' . $this->op_rparam['StoreType:'] . ')':'')) { //已處理過就不處理
                                $order = array();
                                $order['comments'] = vmText::_('SUNSHIP_SHIPPINGMSG') . ':' . urldecode($this->op_rparam["StoreMsg"]) . (($this->op_rparam['StoreType:']!='') ? '(' . vmText::_('SUNSHIP_ERRCODE') . ':' . $this->op_rparam['StoreType:'] . ')':'');
                                $order['customer_notified'] = 1;
                                $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);
                            }

                            $ret = TRUE;
                        }
                    }
                } else {
                    //選擇超商後的受理結果
                    if ($this->op_rparam["ChkValue"] == strtoupper(sha1($this->method->storeid . $this->method->storepwd . $this->op_rparam['buysafeno'] . $this->op_rparam['MN'] . $this->op_rparam['CargoNo']))) {
                        // store op_rparam
                        $dbValues['virtuemart_order_id'] = $this->virtuemart_order_id;
                        $dbValues['order_number'] = $this->payment->order_number;
                        $dbValues['virtuemart_paymentmethod_id'] = $this->payment->virtuemart_paymentmethod_id;
                        $dbValues['payment_name'] = $this->method->payment_name;
                        $dbValues['payment_order_total'] = round($this->payment->order_total);

                        $dbValues['buysafeno'] = $this->op_rparam["buysafeno"];
                        $dbValues['CargoNo'] = $this->op_rparam["CargoNo"];
                        $dbValues['Td'] = $this->op_rparam["Td"];
                        $dbValues['MN'] = $this->op_rparam["MN"];
                        //$dbValues['errcode'] = $this->payment->errcode;
                        //$dbValues['StoreType'] = $this->payment->StoreType;
                        //$dbValues['StoreMsg'] = $this->payment->StoreMsg;
                        $dbValues['StoreName'] = $this->op_rparam["StoreName"];
                        $dbValues['StoreID'] = $this->op_rparam["StoreID"];
                        $dbValues['ChkValue'] = $this->op_rparam["ChkValue"];
                        //$this->storePSPluginInternalData($dbValues, 'virtuemart_order_id', false);
                        // update order
                        if ($this->payment->comments != 'U') { //已處理過就不處理
                            //更新交貨便代碼
                            $order = array();
                            $order['comments'] = vmText::_('SUNSHIP_CARGONO') . ':' . $this->op_rparam['CargoNo'] . sprintf(vmText::_('SUNSHIP_SHIPPING_TRACKING'), $this->op_rparam['CargoNo']);
                            $order['customer_notified'] = 1;
                            $order['order_status'] = 'U';
                            $this->modelOrder->updateStatusForOneOrder($this->virtuemart_order_id, $order, true);

                        }
                        $ret = TRUE;
                    }
                }
                break;
        }
        return $ret;
    }

}

?>
